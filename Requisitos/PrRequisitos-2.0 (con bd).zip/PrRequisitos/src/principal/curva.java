package principal;

import java.util.List;

public interface curva {
    List<parIV> pts = null;
    
   

    void mostrarDatos();
}
