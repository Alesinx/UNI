package principal;

import java.util.List;

public class Modulo {

    private String nombre;
    private List<CurvaOriginal> curvas;

    private double alfa;
    private double beta;
    private double gamma;
    private double kappa;


    public Modulo(){
        nombre = null;
    }
    public Modulo(String n) {
    	//implmentar con sentencias sql
    }
    public Modulo(String n, double a, double b, double g, double k){

        nombre = n;
        alfa = a;
        beta = b;
        gamma = g;
        kappa = k;

    }
    public Modulo(String n, double a, double b, double g, double k,List<CurvaOriginal> list){
        nombre = n;
        alfa = a;
        beta = b;
        gamma = g;
        kappa = k;
        curvas = list;
    }
    public Modulo(List<CurvaOriginal> list){
        this.nombre = null;
        curvas = list;
    }

//---- Getters

    public String getNombre() {
        return nombre;
    }

    public List<CurvaOriginal> getCurvas() {
        return curvas;
    }

    public double getAlfa() {
        return alfa;
    }

    public double getBeta() {
        return beta;
    }

    public double getGamma() {
        return gamma;
    }

    public double getKappa() {
        return kappa;
    }

//----- Setters

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAlfa(double alfa) {
        this.alfa = alfa;
    }

    public void setBeta(double beta) {
        this.beta = beta;
    }

    public void setGamma(double gamma) {
        this.gamma = gamma;
    }

    public void setKappa(double kappa) {
        this.kappa = kappa;
    }


// -----

    public void anyadirCurva (CurvaOriginal c){
        curvas.add(c);
    }

    public void mostrarCurvas(){
        for (curva c : curvas){
            c.mostrarDatos();
        }
    }
}
